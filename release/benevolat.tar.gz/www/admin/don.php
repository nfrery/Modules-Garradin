<?php

namespace Garradin;

$tpl->display(PLUGIN_ROOT . '/templates/don.tpl');
