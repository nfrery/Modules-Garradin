
CREATE TABLE IF NOT EXISTS `plugin_bicycode` (
  `id`	INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE,
  `nom`	TEXT,
  `prenom`	TEXT,
  `adresse`	TEXT,
  `code_postal`	TEXT,
  `ville`	TEXT,
  `numero_piece_identite`	TEXT,
  `date_marquage`	TEXT,
  `telephone`	TEXT,
  `numero_bicycode`	TEXT
);

INSERT INTO `plugin_bicycode` VALUES (1,'Vélo','Jacques','','','','','23/06/2017','','171000300001');
INSERT INTO `plugin_bicycode` VALUES (2,'Bertrand','Phili','','','','','23/06/2017',NULL,'171000300002');
INSERT INTO `plugin_bicycode` VALUES (3,'Nicolas','Fréry',NULL,NULL,NULL,NULL,'23/06/2017',NULL,'171000300003');
INSERT INTO `plugin_bicycode` VALUES (4,'Dubois','Philippe',NULL,NULL,NULL,NULL,'23/06/2017',NULL,'171000300004');
INSERT INTO `plugin_bicycode` VALUES (5,'Latru','Clothilde',NULL,NULL,NULL,NULL,'23/06/2017',NULL,'171000300005');
INSERT INTO `plugin_bicycode` VALUES (6,'Chirac','Bernadette',NULL,NULL,NULL,NULL,'24/06/2017',NULL,'171000300006');