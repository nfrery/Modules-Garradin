DROP TABLE `plugin_benevolat_enregistrement`;
DROP TABLE `plugin_benevolat_categorie`;