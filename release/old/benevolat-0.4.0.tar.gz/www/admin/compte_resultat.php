<?php

namespace Garradin;

$benevolat = new Plugin\Benevolat\BD();
$exercices = new Compta\Exercices;
$comptes = new Compta\Comptes;

$exercice = $exercices->get(qg('id'));

if (!$exercice)
{
    throw new UserException('Exercice inconnu.');
}

$liste_comptes = $comptes->getListAll();

function get_nom_compte($compte)
{
    global $liste_comptes;
    return $liste_comptes[$compte];
}

$tpl->register_modifier('get_nom_compte', 'Garradin\get_nom_compte');
$tpl->assign('compte_resultat', $exercices->getCompteResultat($exercice['id']));

$tpl->assign('cloture', $exercice['cloture'] ? $exercice['fin'] : time());
$tpl->assign('exercice', $exercice);
$tpl->display(PLUGIN_ROOT . '/templates/compte_resultat.tpl');
